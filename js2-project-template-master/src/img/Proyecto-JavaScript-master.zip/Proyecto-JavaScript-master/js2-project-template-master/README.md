# Plantilla de proyectos para el curso de Javascript 2 en el [CETAV](http://parquelalibertad.org/cetav/)

## Requerimientos

* Node.js 8.x o superior (8.12 recomendado)

Usando `nvm`:

```
nvm install 8.12
nvm use 8.12
```

## Uso

```
npm install
npm start
```
